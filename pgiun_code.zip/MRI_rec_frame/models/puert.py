from utils import *
import torch
import torch.nn as nn
import numpy as np
from thop import profile
# device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
# dtype = torch.cuda.FloatTensor if torch.cuda.is_available() else torch.FloatTensor

def make_model(args, parent=False):
    a = torch.Tensor(1, 1, 256, 256)
    k = torch.Tensor(1, 1, 256, 256)
    mask = torch.Tensor(1, 1, 256, 256)

    model = PUERT()
    flops, params = profile(model, (a,k,mask,))
    print('flops: ', flops/1e9, 'params: ', params/1e6)

    total_params = sum(p.numel() for p in model.parameters())
    print(f'{total_params:,} total parameters.')
    total_trainable_params = sum(
        p.numel() for p in model.parameters() if p.requires_grad)
    print(f'{total_trainable_params:,} training parameters.')
    return model


def zero_filled(x, mask, mod=False, norm=False):
        '''
        :param x: tensor of size (bs, C, H, W), C=1 for real image, C=2 for complex image
        :param mask: 1,H,W,1
        '''
        k_temp= torch.fft.fftshift(torch.fft.fft2(x))
        y_kspace = k_temp * mask
        xu = torch.abs(torch.fft.ifft2(torch.fft.ifftshift(y_kspace, dim=(-2, -1))))

        return xu

class CSE_Block(nn.Module):
    def __init__(self, in_ch, out_ch, r):
        super(CSE_Block, self).__init__()
        self.layer = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(in_ch, int(in_ch / r), kernel_size=1),
            nn.ReLU(),
            nn.Conv2d(int(in_ch / r), in_ch, kernel_size=1),
            nn.Sigmoid()
        )
        self.tail =  nn.Conv2d(in_ch, out_ch, kernel_size=1)
    def forward(self, x):
        s = self.layer(x)
        s= s*x
        out = self.tail(s)
        return out
        
class DC_layer_I(nn.Module):
    def __init__(self):
        super(DC_layer_I, self).__init__()

    def forward(self,  x_rec, x_under,mask):
        k_temp= torch.fft.fftshift(torch.fft.fft2(x_rec))
        matrixones = torch.ones_like(mask.data)  # 全为1：(16, 1, 256, 256)
        k_rec_dc = (matrixones - mask) * k_temp + x_under
        out = torch.abs(torch.fft.ifft2(torch.fft.ifftshift(k_rec_dc, dim=(-2, -1))))
        return out  # (16, 1, 256, 256)


class BinaryQuantize(torch.autograd.Function):
    @staticmethod
    def forward(ctx, input, k, t, sparse_ratio_):
        ctx.save_for_backward(input, k, t)
        out = input.new(input.size())
        out[input >= 0] = 1
        out[input < 0] = 0
        return out

    @staticmethod
    def backward(ctx, grad_output):
        input, k, t = ctx.saved_tensors
        grad_input = k * t * (1 - torch.pow(torch.tanh(input * t * 2), 2)) * grad_output
        return grad_input, None, None, None

    
class PUERT(torch.nn.Module):
    def __init__(self, LayerNo=9 , rb_num=2):
        super(PUERT, self).__init__()

        onelayer = []
        self.LayerNo = LayerNo
        basicblock = ISTA_2RB_BasicBlock
        for i in range(LayerNo):
            onelayer.append(basicblock(rb_num=rb_num))

        self.fcs = nn.ModuleList(onelayer)
        self.dc = DC_layer_I()
    def forward(self, img, kspace_sam, mask):
        xu_real = zero_filled(img, mask)
        x = img

        for i in range(self.LayerNo):
            x = self.fcs[i](x, xu_real, mask)
            x = self.dc(x,kspace_sam,mask)
        x_final = x

        return x_final

    def initialize_p(self, eps=0.01):
        x = torch.from_numpy(np.random.uniform(low=eps, high=1-eps, size=self.mask_shape)).type(dtype)
        return - torch.log(1. / x - 1.) / self.pmask_slope


    

class ISTA_2RB_BasicBlock(torch.nn.Module):
    def __init__(self, rb_num):
        super(ISTA_2RB_BasicBlock, self).__init__()

        self.lambda_step = nn.Parameter(torch.Tensor([0.5]))
        self.soft_thr = nn.Parameter(torch.Tensor([0.01]))

        kernel_size = 3
        bias = True
        n_feat = 32

        self.conv_D = nn.Conv2d(1, n_feat, kernel_size, padding=(kernel_size//2), bias=bias)

        modules_body = [Residual_Block(n_feat, n_feat, 3, bias=True, res_scale=1) for _ in range(rb_num)]

        self.body = nn.Sequential(*modules_body)

        self.conv_G = nn.Conv2d(n_feat, 1, kernel_size, padding=(kernel_size//2), bias=bias)

    def forward(self, x, PhiTb, mask):
        x = x - self.lambda_step * zero_filled(x, mask)
        x = x + self.lambda_step * PhiTb
        x_input = x

        x_D = self.conv_D(x_input)

        x_backward = self.body(x_D)

        x_G = self.conv_G(x_backward)

        x_pred = x_input + x_G

        return x_pred

class Residual_Block(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, bias=True, res_scale=1):

        super(Residual_Block, self).__init__()
        self.res_scale = res_scale
        self.conv1 = nn.Conv2d(in_channels, out_channels, kernel_size, padding=(kernel_size//2), bias=bias)
        self.conv2 = nn.Conv2d(out_channels, out_channels, kernel_size, padding=(kernel_size//2), bias=bias)
        self.act1 = nn.ReLU(inplace=True)

    def forward(self, x):
        input = x
        x = self.conv1(x)
        x = self.act1(x)
        x = self.conv2(x)
        res = x
        x = res * self.res_scale + input
        return x
